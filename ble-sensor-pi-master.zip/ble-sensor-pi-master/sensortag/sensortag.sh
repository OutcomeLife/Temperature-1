#!/bin/sh
# This is a template.
# You'll need to change the values on each of these line to yours.
export XIVELY_API_KEY="QwertyUiopAsdfgHjklZxcvBnm1234567890"
export XIVELY_FEED_ID="1234567890"
./sensortag_xively.py DE:AD:DE:AD:DE:AD

